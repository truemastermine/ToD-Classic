-- @class ROLE

function ROLE:preInit()
	self.index = "null"
end

function ROLE:init()

end

function ROLE:goal()

end